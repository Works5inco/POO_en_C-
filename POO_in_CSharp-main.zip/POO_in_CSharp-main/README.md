# POO_in_CSharp
Trucos sencillos para programar con objetos en C# (dotnet_SDK) 
